# Ornamental Fish Science — v2.5.0 Minimum-Functionality fix

Drop-in source package built from `OrnamentalFish-v2.4.4-NEW-STORE-READY.apk` plus the native chrome / JS bridge Play asked for.

Package name recovered from the APK: `com.tnfisheries.ornamentalfish`.

This sandbox has no Android SDK, so this tree is source only. Build and sign it in Android Studio with the same release keystore you used for v2.4.4.

## What was wrong

Google Play's "Minimum Functionality" rejection is triggered by a structural pattern, not by whether content is bundled offline (yours already was). v2.4.4's native layer is a single WebView-only `MainActivity` with zero chrome outside it — all navigation lives in `assets/js/app.js` as an HTML tab bar. That is indistinguishable, to Play's review pipeline, from "a website wrapped in a frame."

## What this package changes

Two independent drops — apply both.

### 1. `assets/` → overwrite `app/src/main/assets/`

- New `AndroidBridge` JS layer in `app.js`: 🔊 pronounce (TTS), ⇪ share, ⏰ revision reminder, ⇩ bookmark export — each with a Web-API fallback, so the page still works standalone in a browser.
- Hides the in-page HTML tab bar once native chrome is present (`hasNative()` check in `boot()`), so you don't get two nav bars.
- Fixed the version-string drift (title said 2.4.4, the internal `VERSION` constant said 2.4.3) → unified to **2.5.0**.

### 2. `native/app/src/main/` → merge into your project's `app/src/main/`

This is what actually answers the Play flag: a real `Toolbar` + `BottomNavigationView` wrapping the WebView, plus the Java side of the four bridge calls.

Bug found and fixed along the way: `app.js` already defines `window.__appBack()` to close a species-detail view / return to Home, but the compiled v2.4.4 `MainActivity` never called it — `onBackPressed` only checked `WebView.canGoBack()` (almost always false in a single-page app) and otherwise called `finish()`. In the shipped app, pressing Back while viewing a species account exits the whole app instead of returning to the Atlas list. Fixed by querying JS first via the `OnBackPressedDispatcher`.

A monochrome `ic_stat_notify` vector is included so the revision notification is not a white blob of the colour launcher icon.

## Integration steps (Android Studio)

1. **Assets** — replace `app/src/main/assets/*` with this package's `assets/*`.
2. **Manifest** — merge `native/app/src/main/AndroidManifest.xml` into your existing manifest. It adds:
   - `<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>`
   - the `<receiver android:name=".ReminderReceiver" .../>` entry
   - `android:theme="@style/Theme.OrnamentalFish.Splash"` on the launcher activity, `android:theme="@style/Theme.OrnamentalFish"` on `<application>`
   - Read the comment block at the top of that file. `usesCleartextTraffic="false"` is deliberate.
3. **Java sources** — copy the three files in `native/app/src/main/java/com/tnfisheries/ornamentalfish/` into your existing package of the same name, replacing `MainActivity.java` and adding `WebAppInterface.java` and `ReminderReceiver.java`.
4. **Resources** — copy `native/app/src/main/res/{layout,menu,drawable,values,color}/*` into `app/src/main/res/`.
   - If `colors.xml` or `strings.xml` already exist, merge the new `<color>` / `<string>` entries rather than overwriting.
   - `drawable/app_icon.png` is the launcher recovered from the compiled APK (`res/aH.png`, 432×432). Keep your existing adaptive-icon / mipmap set if it is already nicer — only the filename `@drawable/app_icon` must resolve.
5. **build.gradle** — apply the additions in `native/build.gradle.additions.txt` (AppCompat, AndroidX Activity, Material Components; core-splashscreen is optional).
6. **Version bump** — set `versionName` to `2.5.0` and `versionCode` to one higher than the last Play upload. The manifest here does not set these.

## Before you resubmit — QA pass

- Bottom nav's 5 items switch the WebView tab both ways (tap a home-screen tile that jumps to Quiz — the bottom nav should update to match; tap a bottom-nav item — the page should follow).
- Open a species account, press the system Back button — you should land back on the Atlas list, not exit the app. Press Back again from Atlas → Home. Press Back from Home → app exits.
- 🔊 Pronounce speaks the species name in English; in Tamil mode, either speaks Tamil or shows the "Tamil voice not installed" toast (don't ship if it silently does nothing).
- ⇪ Share opens the native Android share sheet with a species fact-sheet as text.
- From a finished quiz, "Remind me to revise tomorrow" → on Android 13+, a notification-permission prompt appears once; granting it should produce a notification roughly a day later. For a fast manual test, temporarily change the `24` in `data-remind` / `scheduleReminder(24, ...)` in `app.js` to a small number of hours, test, then change it back before release.
- From Bookmarks (with at least one saved), ⇩ Export opens the Android "Save to…" file picker and writes a readable `.txt`.

## Files

```
assets/                  ← overwrite app/src/main/assets/
native/app/src/main/     ← merge into app/src/main/
native/build.gradle.additions.txt
original-from-apk/       ← untouched v2.4.4 app.js / index.html for diffing
```
